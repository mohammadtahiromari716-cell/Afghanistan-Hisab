# افغانستان حساب (Tahir Admin)

A lightweight Capacitor 6 Android app starter.

## Build APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the **contents** of this ZIP (not the ZIP file itself) to the repository root.
3. Ensure the default branch is `main` or `master`.
4. Open **Actions** and run **Build Afghanistan Hisab APK**.
5. When the run is green, open the run and download the `Afghanistan-Hisab-APK` artifact.

The workflow creates the Android project on the GitHub runner, syncs the `www` web app, and builds a debug APK.

## Important
- Web assets are in `www/`; Capacitor `webDir` is set to `www`.
- This starter stores data locally in the phone browser storage. It does not yet sync accounts between devices or provide a cloud database.
- The app opens with a 4-digit PIN screen. Default PIN: `1234`. Change it in Settings after entering the app.
